import pygame
import random

pygame.init()

WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE = (255, 255, 255)
RED = (255, 0, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Scavenger")

spaceship_img = pygame.image.load("spaceship_game_resources/spaceship.png")
asteroid_img = pygame.image.load("spaceship_game_resources/asteroid.png")
energy_crystal_img = pygame.image.load("spaceship_game_resources/energy_crystal.png")
background_img = pygame.image.load("spaceship_game_resources/background1.png")
background_music = "spaceship_game_resources/background_music.wav"
clash_sound = "spaceship_game_resources/clash_sound.wav"
heart_img = pygame.image.load("spaceship_game_resources/heart1.png")

spaceship_img = pygame.transform.scale(spaceship_img, (50, 50))
background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT))
heart_img = pygame.transform.scale(heart_img, (30, 30))

pygame.mixer.music.load(background_music)
clash_effect = pygame.mixer.Sound(clash_sound)

spaceship_x, spaceship_y = WIDTH // 2, HEIGHT - 100
spaceship_speed = 5
asteroids = []
crystals = []
asteroid_speed = 3
score = 0
lives = 3
level = 1
clock = pygame.time.Clock()
running = True
invulnerable = 0

def draw_spaceship(x, y):
    screen.blit(spaceship_img, (x, y))

def draw_asteroids():
    for asteroid in asteroids:
        x, y, size, _ = asteroid
        scaled_asteroid = pygame.transform.scale(asteroid_img, (size, size))
        screen.blit(scaled_asteroid, (x, y))

def draw_crystals():
    for crystal in crystals:
        x, y, size = crystal
        scaled_crystal = pygame.transform.scale(energy_crystal_img, (size - 10, size - 10))
        screen.blit(scaled_crystal, (x, y))

def generate_asteroid():
    x = random.randint(0, WIDTH - 60)
    y = random.randint(-100, -40)
    direction = random.choice([-1, 1])
    size = random.randint(40 + level * 8, 80 + level * 8)
    asteroids.append([x, y, size, direction])

def generate_crystal():
    x = random.randint(0, WIDTH - 40)
    y = random.randint(-100, -40)
    size = random.randint(35, 60)
    crystals.append([x, y, size])

pygame.mixer.music.play(-1)

def reset_game():
    global spaceship_x, spaceship_y, asteroids, crystals, score, lives, level, asteroid_speed, invulnerable
    spaceship_x, spaceship_y = WIDTH // 2, HEIGHT - 100
    asteroids.clear()
    crystals.clear()
    score = 0
    lives = 3
    level = 1
    asteroid_speed = 3
    invulnerable = 0

def draw_lives():
    heart_spacing = 10
    total_width = (heart_img.get_width() + heart_spacing) * lives - heart_spacing
    start_x = (WIDTH - total_width) // 2
    for i in range(lives):
        screen.blit(heart_img, (start_x + i * (heart_img.get_width() + heart_spacing), 10))

while running:
    reset_game()

    while lives > 0:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and spaceship_x > 0:
            spaceship_x -= spaceship_speed
        if keys[pygame.K_RIGHT] and spaceship_x < WIDTH - 50:
            spaceship_x += spaceship_speed
        if keys[pygame.K_UP] and spaceship_y > HEIGHT // 2:
            spaceship_y -= spaceship_speed
        if keys[pygame.K_DOWN] and spaceship_y < HEIGHT - 50:
            spaceship_y += spaceship_speed

        if random.randint(1, 60) == 1:
            generate_asteroid()
        if random.randint(1, 80) == 1:
            generate_crystal()

        for asteroid in asteroids[:]:
            asteroid[1] += asteroid_speed
            asteroid[0] += asteroid[3]
            if asteroid[1] > HEIGHT or asteroid[0] < 0 or asteroid[0] > WIDTH:
                asteroids.remove(asteroid)

        for crystal in crystals[:]:
            crystal[1] += asteroid_speed - 1
            if crystal[1] > HEIGHT:
                crystals.remove(crystal)

        spaceship_rect = pygame.Rect(spaceship_x, spaceship_y, 50, 50)
        if invulnerable > 0:
            invulnerable -= 1

        for asteroid in asteroids[:]:
            asteroid_rect = pygame.Rect(asteroid[0], asteroid[1], asteroid[2], asteroid[2])
            if spaceship_rect.colliderect(asteroid_rect) and invulnerable == 0:
                clash_effect.play()
                lives -= 1
                invulnerable = 60
                asteroids.remove(asteroid)
                if lives <= 0:
                    break

        for crystal in crystals[:]:
            crystal_rect = pygame.Rect(crystal[0], crystal[1], crystal[2], crystal[2])
            if spaceship_rect.colliderect(crystal_rect):
                score += 1
                crystals.remove(crystal)

        if score > 0 and score % 10 == 0 and score // 10 > level - 1:
            level += 1
            asteroid_speed += 0.5

        screen.blit(background_img, (0, 0))
        draw_spaceship(spaceship_x, spaceship_y)
        draw_asteroids()
        draw_crystals()
        draw_lives()

        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {score}", True, WHITE)
        level_text = font.render(f"Level: {level}", True, WHITE)

        screen.blit(score_text, (10, 10))

        level_text_x = WIDTH - 10 - level_text.get_width()
        screen.blit(level_text, (level_text_x, 10))

        pygame.display.flip()
        clock.tick(FPS)

    def draw_try_again_button():
        button_width, button_height = 200, 50
        button_x = WIDTH // 2 - button_width // 2
        button_y = HEIGHT // 2 + 100
        pygame.draw.rect(screen, RED, (button_x, button_y, button_width, button_height))
        font = pygame.font.Font(None, 36)
        try_again_text = font.render("Try Again", True, WHITE)
        screen.blit(try_again_text, (button_x + button_width // 2 - try_again_text.get_width() // 2, button_y + button_height // 2 - try_again_text.get_height() // 2))

    waiting = True
    while waiting:
        screen.fill(WHITE)
        font = pygame.font.Font(None, 48)
        game_over_text = font.render("Game Over", True, RED)
        final_score_text = font.render(f"Final Score: {score}", True, RED)
        screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 50))
        screen.blit(final_score_text, (WIDTH // 2 - final_score_text.get_width() // 2, HEIGHT // 2 + 10))

        draw_try_again_button()

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                button_rect = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 100, 200, 50)
                if button_rect.collidepoint(mouse_pos):
                    reset_game()
                    waiting = False
                    running = True

pygame.quit()
