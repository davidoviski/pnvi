import pygame
import sys
import random

WIDTH, HEIGHT = 600, 700
GRID_SIZE = 5
SQUARE_SIZE = WIDTH // GRID_SIZE
COLORS = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
GRAY = (200, 200, 200)
WHITE = (255, 255, 255)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Color Fill Puzzle")
font = pygame.font.Font(None, 36)


grid = [[None for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
pre_filled = 5

for _ in range(pre_filled):
    row, col = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
    color = random.choice(COLORS)
    grid[row][col] = color

def draw_grid():

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            color = grid[row][col] if grid[row][col] else GRAY
            pygame.draw.rect(screen, color, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))
            pygame.draw.rect(screen, WHITE, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 2)

def draw_color_selector():

    y_offset = GRID_SIZE * SQUARE_SIZE + 10
    for i, color in enumerate(COLORS):
        pygame.draw.rect(screen, color, (i * 100 + 50, y_offset, 80, 50))
        pygame.draw.rect(screen, WHITE, (i * 100 + 50, y_offset, 80, 50), 2)

def is_valid_color(row, col, color):

    neighbors = [
        (row - 1, col),  # Above
        (row + 1, col),  # Below
        (row, col - 1),  # Left
        (row, col + 1)   # Right
    ]
    for r, c in neighbors:
        if 0 <= r < GRID_SIZE and 0 <= c < GRID_SIZE and grid[r][c] == color:
            return False
    return True

def check_win():

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            if not grid[row][col]:
                return False
    return True

def draw_win_screen():

    screen.fill(WHITE)
    win_text = font.render("You Win!", True, (0, 0, 0))
    screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, HEIGHT // 2 - 60))

    button_rect = pygame.Rect(WIDTH // 2 - 75, HEIGHT // 2, 150, 50)
    pygame.draw.rect(screen, (0, 200, 0), button_rect)
    pygame.draw.rect(screen, WHITE, button_rect, 2)

    button_text = font.render("Try Again", True, WHITE)
    screen.blit(button_text, (WIDTH // 2 - button_text.get_width() // 2, HEIGHT // 2 + 10))
    return button_rect

def main():
    running = True
    game_won = False
    selected_color = COLORS[0]

    while running:
        if game_won:
            button_rect = draw_win_screen()
            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if button_rect.collidepoint(event.pos):

                        for row in range(GRID_SIZE):
                            for col in range(GRID_SIZE):
                                grid[row][col] = None
                        for _ in range(pre_filled):
                            row, col = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
                            color = random.choice(COLORS)
                            grid[row][col] = color
                        game_won = False
        else:
            screen.fill(WHITE)
            draw_grid()
            draw_color_selector()

            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos


                    if y > GRID_SIZE * SQUARE_SIZE:
                        for i, color in enumerate(COLORS):
                            if i * 100 + 50 <= x <= i * 100 + 130 and GRID_SIZE * SQUARE_SIZE + 10 <= y <= GRID_SIZE * SQUARE_SIZE + 60:
                                selected_color = color
                    else:

                        col, row = x // SQUARE_SIZE, y // SQUARE_SIZE
                        if grid[row][col] is None:
                            if is_valid_color(row, col, selected_color):
                                grid[row][col] = selected_color

                        if check_win():
                            game_won = True

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
